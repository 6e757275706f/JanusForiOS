# JanusForiOS-Restore-Script-
This GitHub repository contains an Xcode Project that is still in development.
This is the script that restores any files that were backed up to /var/mobile/Documents/Backups/BKP# to /var/mobile/Library/Preferences
