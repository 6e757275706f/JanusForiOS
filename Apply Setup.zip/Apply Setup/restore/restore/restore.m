//
//  main.m
//  restore
//
//  Created by iOS_Designr.psd on 8/15/16.
//  Copyright © 2016 iOS_Designr.psd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UIViewController.h"
#import "SecondViewController.h"
#import "FCAlertView.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

@interface UIViewController ()

@end

@implementation UIViewController

int main(int argc, const char * argv[]) {
    NSFileManager *manager = [NSFileManager defaultManager];
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    NSString *backupsDir = @"/Volumes/El Capitan Storage 224 1/System/Users/sparkscatcher/Library/Developer/Xcode/DerivedData/CPTEST-fsovzxqsngoqchewswdmcnebzuib/Build/Products/Debug/var/mobile/Documents/Backups/";

//Most of the NSStrings here will indicate a path on iOS_Deignr.psd's computer, therefore, if you would like to test this script, I belive you would have to change the filepaths to indicate a directory on your computer.
//The var folder can be at the following link...
//https://drive.google.com/folderview?id=0B0Eh76ySV9q5R29Bd21UNUtoaEU&usp=sharing
    
    NSError *error;
    
    //isolate backups
    
    NSArray *backupFolder = [manager contentsOfDirectoryAtPath:backupsDir error:nil];
    NSArray *backupFiles = [backupFolder filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self CONTAINS 'BKP'"]];
    
    //Check how many files in backupFiles
    
    NSInteger b = [backupFiles count];
    NSLog(@"%ld", (long)b);
    
    NSString *nameofRestore = @"NAME_CHOSEN_BY_USER_AT_TIME_OF_BACKUP";
    
    int w = 0;
    
retry:

//This part will continue to look for the correct file name (Indicated by nameofRestore) until it finds what folder it's located in
    
    {
    NSLog(@"%d", w);
        
    NSString *bkppath = [NSString stringWithFormat:@"/Volumes/El Capitan Storage 224 1/System/Users/sparkscatcher/Library/Developer/Xcode/DerivedData/CPTEST-fsovzxqsngoqchewswdmcnebzuib/Build/Products/Debug/var/mobile/Documents/Backups/BKP%d", w];
    
    NSString *namepath = [NSString stringWithFormat:@"/Volumes/El Capitan Storage 224 1/System/Users/sparkscatcher/Library/Developer/Xcode/DerivedData/CPTEST-fsovzxqsngoqchewswdmcnebzuib/Build/Products/Debug/var/mobile/Documents/Backups/BKP%d/%@", w, nameofRestore];
    
    NSString *prefPath = [NSString stringWithFormat:@"/Volumes/El Capitan Storage 224 1/System/Users/sparkscatcher/Library/Developer/Xcode/DerivedData/CPTEST-fsovzxqsngoqchewswdmcnebzuib/Build/Products/Debug/var/mobile/Documents/Backups/BKP%d/Preferences", w];
    
       NSArray *filesinBKPPref = [manager contentsOfDirectoryAtPath:prefPath error:nil];
        
    //This is an array of all the files from the correct preference backup
        
        NSLog(@"%@", namepath);
        
    //The file TEST is located at this directory: Backups/BKP2/TEST, so when w = 2, Console should output Found, and the path
    //This script works. It checks the file name of the file in BKP# to check if it corralates to nameofRestore
    
    if ([manager fileExistsAtPath: namepath]){
        NSLog(@"Found correct Backup: %@", bkppath);
        NSLog(@"Contents of Prefs: %@", filesinBKPPref);
        
        //NOTE: At this point, bkppath and any path with BKP%d reffers to the folder of the correct backup (the one that must be restored)
        
        goto restore;
        }
    else{
        NSLog(@"Nope");
        w++;
        goto retry;
        }
    }
restore:
    
//Here, the contents of prefPath need to be copied to inside the dir rootPath, effectively overwriting any file that needs to be restored.
//ONLY THOSE must be overwritten, and make sure the plists excluded from the actual backup process DO NOT get deleted from /Library/Preferences (AKA: "com.apple", "BytaFont", etc. [See Backup file for reference as to what has not been deleted]).
//Also the IconSupport file must be Atomically copied (So that it doesn't give you an error that the file exists already) from iconsupportFile to iconsupportDest
    
    {
    NSString *iconsupportFile = [NSString stringWithFormat:@"/Volumes/El Capitan Storage 224 1/System/Users/sparkscatcher/Library/Developer/Xcode/DerivedData/CPTEST-fsovzxqsngoqchewswdmcnebzuib/Build/Products/Debug/var/mobile/Documents/Backups/BKP%d/IconSupportState.plist", w];
    
    NSString *iconsupportDest = @"/Volumes/El Capitan Storage 224 1/System/Users/sparkscatcher/Library/Developer/Xcode/DerivedData/CPTEST-fsovzxqsngoqchewswdmcnebzuib/Build/Products/Debug/var/mobile/Library/Springboard/IconSupportState.plist";
        
//Removal of original IconSupportState
        
        {
        if ([manager removeItemAtPath:iconsupportDest error:&error]){
            NSLog(@"Removal of IconSupportState Success");
            }
        else{
            NSLog(@"REMOVAL ERROR: %@", error);
            }
            
        }

//Copying of Backed up IconSupportState
        
        {
        if ([manager copyItemAtPath:iconsupportFile toPath:iconsupportDest error:&error]){
            NSLog(@"Copy of backed up version Success");
            }
        else{
            NSLog(@"COPY ERROR: %@", error);
            }

        }
    }
    
//NOTE: The method used with IconSupportState can only be used for that and not for the Prefrences, UNLESS all the equivalents of all the files in the BKP# can be isolated in Library/Preferences, as to only delete the files that will be replaced, and not all of them, as not all of them are backed up.
    
    {
        
    NSString *rootPath = [NSString stringWithFormat:@"/Volumes/El Capitan Storage 224 1/System/Users/sparkscatcher/Library/Developer/Xcode/DerivedData/CPTEST-fsovzxqsngoqchewswdmcnebzuib/Build/Products/Debug/var/mobile/Library/Preferences"];
        
    //isolate bkped files only
    NSArray *dirFiles = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:rootPath error:nil];
    NSArray *bkpFilesOnly = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"NOT (self BEGINSWITH 'com.apple') AND NOT (self ENDSWITH '.license') AND NOT (self ENDSWITH '.signed') AND NOT (self ENDSWITH '.allapps') AND NOT (self ENDSWITH '.alldevices') AND NOT (self ENDSWITH 'BytaFontBackup') AND NOT (self BEGINSWITH 'nfcd.plist') AND NOT (self BEGINSWITH 'BytaFont3.plist') AND NOT (self BEGINSWITH 'com.assistantplus.app.plist') AND NOT (self BEGINSWITH 'com.bolencki13.customft') AND NOT (self BEGINSWITH 'com.broganminer.wave.plist') AND NOT (self BEGINSWITH 'com.creatix.peekaboo.plist') AND NOT (self BEGINSWITH 'com.gsquared.senddelay.plist') AND NOT (self BEGINSWITH 'com.imokhles.revealMenu') AND NOT (self BEGINSWITH 'com.j290.CarPlay') AND NOT (self BEGINSWITH 'com.jake0oo0.instabetter') AND NOT (self BEGINSWITH 'com.kindadev.goodfit') AND NOT (self BEGINSWITH 'com.rpetrich.curiosa') AND NOT (self CONTAINS 'Cydia') AND NOT (self BEGINSWITH 'com.tigisoftware') AND NOT (self BEGINSWITH 'com.tweaksbylogan.3dapplock') AND NOT (self BEGINSWITH 'com.yeomans.programmablesms') AND NOT (self CONTAINS 'crash') AND NOT (self BEGINSWITH 'group.com.apple') AND NOT (self BEGINSWITH 'kbd') AND NOT (self BEGINSWITH 'pairedsyncd') AND NOT (self BEGINSWITH 'ProtectedCloudKeySyncing') AND NOT (self BEGINSWITH 'tw_wl_tp') AND NOT (self BEGINSWITH 'UITextInputContextIdentifiers') AND NOT (self BEGINSWITH 'libactivator')"]];
        
    NSLog(@"If this shows any com.apple, BytaFont, License etc., you failed: %@", bkpFilesOnly);

        
        // remove all files except untamperables from rootPref
        for(NSInteger i = 0; i < [bkpFilesOnly count]; ++i)
        {
            NSString *fp =  [bkpFilesOnly objectAtIndex: i];
            NSString *remPath = [rootPath stringByAppendingPathComponent: fp];
            if ([manager removeItemAtPath: remPath error: nil]){
                NSLog(@"Deletion of file except untamperables Success");
            }
            else{
                NSLog(@"DELETE ERROR: %@", error);
            }
        }
        
        //Restore Preference Files. (WORKING)
    NSString *prefPath = [NSString stringWithFormat:@"/Volumes/El Capitan Storage 224 1/System/Users/sparkscatcher/Library/Developer/Xcode/DerivedData/CPTEST-fsovzxqsngoqchewswdmcnebzuib/Build/Products/Debug/var/mobile/Documents/Backups/BKP%d/Preferences", w];
        
    NSArray *filesinBKPPref = [manager contentsOfDirectoryAtPath:prefPath error:nil];

        for (NSString *file in filesinBKPPref) {
            [manager copyItemAtPath:[prefPath stringByAppendingPathComponent:file]
                        toPath:[rootPath stringByAppendingPathComponent:file]
                         error:nil];
            //Restore This Setup should be connected to this for Testing Purposes only
            FCAlertView *alert = [[FCAlertView alloc] init];
            
            [alert showAlertInView:self
                         withTitle:@"Restore Complete"
                      withSubtitle:@"Please Respring Device Now! (THIS IS A TEST)"
                   withCustomImage:nil
               withDoneButtonTitle:nil
                        andButtons:@[@"OK"]];
        }

    }

    [pool drain];
    return 0;
}