# JanusForiOS-Backup-Script-
This GitHub repository contains an Xcode Project that is still in development. This is the script that backs up most preference files from/var/mobile/Library/Preferences to /var/mobile/Documents/Backups/BKP#
Nothing needs to be done with this script until it is ready for implementation. At that point the paths will be modified according to the iOS filesystem.
