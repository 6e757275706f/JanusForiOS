//
//  main.m
//  CPTEST
//
//  Created by iOS_Designr.psd on 8/13/16.
//  Copyright © 2016 iOS_Designr.psd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

int main(int argc, const char * argv[]) {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    NSFileManager *manager = [NSFileManager defaultManager];
    NSString *path;
    
    NSString *backupsDir = @"/Volumes/El Capitan Storage 224 1/System/Users/sparkscatcher/Library/Developer/Xcode/DerivedData/CPTEST-fsovzxqsngoqchewswdmcnebzuib/Build/Products/Debug/var/mobile/Documents/Backups/";
    
    NSError *error;
    
    //isolate backups
    NSArray *backupFolder = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:backupsDir error:nil];
    NSArray *backupFiles = [backupFolder filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self CONTAINS 'BKP'"]];
    
    //Check how many files in backupFiles
    NSInteger b = [backupFiles count];
    NSLog(@"%ld", (long)b);
    
    //Name the directories that are not constant (ie BKP%d)
    
    NSString *fileName = @"NAME_CHOSEN_BY_USER_AT_TIME_OF_BACKUP";
    
    NSString *destDir   = [NSString stringWithFormat:@"/Volumes/El Capitan Storage 224 1/System/Users/sparkscatcher/Library/Developer/Xcode/DerivedData/CPTEST-fsovzxqsngoqchewswdmcnebzuib/Build/Products/Debug/var/mobile/Documents/Backups/BKP%ld/Preferences", (long)b];
    
    NSString *desticonDir   = [NSString stringWithFormat:@"/Volumes/El Capitan Storage 224 1/System/Users/sparkscatcher/Library/Developer/Xcode/DerivedData/CPTEST-fsovzxqsngoqchewswdmcnebzuib/Build/Products/Debug/var/mobile/Documents/Backups/BKP%ld/IconSupportState.plist", (long)b];
    
    NSString *startDir = [NSString stringWithFormat:@"/Volumes/El Capitan Storage 224 1/System/Users/sparkscatcher/Library/Developer/Xcode/DerivedData/CPTEST-fsovzxqsngoqchewswdmcnebzuib/Build/Products/Debug/var/mobile/Documents/Backups/BKP%ld", (long)b];
    
    NSString *fileDir = [NSString stringWithFormat:@"/Volumes/El Capitan Storage 224 1/System/Users/sparkscatcher/Library/Developer/Xcode/DerivedData/CPTEST-fsovzxqsngoqchewswdmcnebzuib/Build/Products/Debug/var/mobile/Documents/Backups/BKP%ld/%@", (long)b, fileName];
    
    
    //create directory of backup
    if([manager createDirectoryAtPath:startDir withIntermediateDirectories:YES attributes:nil error:&error]) {
        NSLog(@"Creation Success");
    }
    else{
        NSLog(@"CREATION ERROR");
    }
    
    //create file with name of backup
    if([manager createFileAtPath:fileDir contents:nil attributes:nil]) {
        NSLog(@"Creation Success");
    }
    else{
        NSLog(@"CREATION ERROR");
    }


    //get current dir
    path = [manager currentDirectoryPath];
    NSLog(@"Current Path: %@", path);

    //copy preferences
    if ([manager copyItemAtPath:@"var/mobile/Library/Preferences/" toPath:destDir error:&error]){
        NSLog(@"Copy Success");
    }
    else{
        NSLog(@"COPY ERROR: %@", error);
    }
    
    //copy IconSupport layout
    if ([manager copyItemAtPath:@"var/mobile/Library/Springboard/IconSupportState.plist" toPath:desticonDir error:&error]){
        NSLog(@"Copy Success");
    }
    else{
        NSLog(@"COPY ERROR: %@", error);
    }

    
    //change dir
    if ([manager changeCurrentDirectoryPath: destDir] == NO)
        NSLog (@"Cannot change directory.");
    
    path = [manager currentDirectoryPath];
    NSLog(@"Current Path: %@", path);
    
    //isolate lincense files
    NSArray *dirFiles = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:path error:nil];
    NSArray *licenseFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self ENDSWITH '.license'"]];
    
    //isolate remaining lincense files
    NSArray *remlicFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self ENDSWITH '.signed'"]];
    
    //isolate allapps files
    NSArray *allappsFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self ENDSWITH '.allapps'"]];
    
    //isolate alldevices files
    NSArray *alldevFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self ENDSWITH '.alldevices'"]];

    //isolate BytaFont Backup
    NSArray *bytafontFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self ENDSWITH 'BytaFontBackup'"]];
    
    //isolate Apple PLISTs
    NSArray *appleFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.apple'"]];

    //isolate nfcd
    NSArray *nfcdFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'nfcd.plist'"]];
    
    //isolate bytafont plist
    NSArray *bytaplistFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'BytaFont3.plist'"]];
    
    //isolate Assistant+
    NSArray *siriplusFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.assistantplus.app.plist'"]];
    
    //isolate customft
    NSArray *customftFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.bolencki13.customft'"]];
    
    //isolate Wave2Unlock
    NSArray *waveFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.broganminer.wave.plist'"]];
    
    //isolate peekaboo
    NSArray *peekabooFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.creatix.peekaboo.plist'"]];
    
    //isolate senddelay
    NSArray *senddelayFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.gsquared.senddelay.plist'"]];
    
    //isolate revealmenu
    NSArray *revealmenuFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.imokhles.revealMenu'"]];
    
    //isolate carplayios
    NSArray *carplayFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.j290.CarPlay'"]];

    //isolate instabetter
    NSArray *instabetterFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.jake0oo0.instabetter'"]];
    
    //isolate fgoodfit
    NSArray *fgfFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.kindadev.goodfit'"]];
    
    //isolate curiosa
    NSArray *curiosaFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.rpetrich.curiosa'"]];
    
    //isolate cydia
    NSArray *cydiaFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self CONTAINS 'Cydia'"]];
    
    //isolate filza
    NSArray *filzaFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.tigisoftware'"]];
    
    //isolate 3dapplock
    NSArray *forceapplockFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.tweaksbylogan.3dapplock'"]];
    
    //isolate programmablesms
    NSArray *progsmsFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'com.yeomans.programmablesms'"]];
    
    //isolate crashreporter
    NSArray *crashFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self CONTAINS 'crash'"]];
    
    //isolate more Apple Files
    NSArray *moreappleFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'group.com.apple'"]];
    
    //isolate even more Apple Files
    NSArray *evenmoreappleFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'kbd'"]];
    
    //isolate extemely more Apple Files
    NSArray *exmoreappleFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'pairedsyncd'"]];
    
    //isolate ridiculously more Apple Files
    NSArray *ridmoreappleFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'ProtectedCloudKeySyncing'"]];
    
    //OK, I'm done with Apple Files
    NSArray *NOMOREappleFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'tw_wl_tp'"]];
    
    //Leave now and NEVER come BACK.
    NSArray *isitoverappleFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'UITextInputContextIdentifiers'"]];
    
    //isolate Activator
    NSArray *libactFiles = [dirFiles filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"self BEGINSWITH 'libactivator'"]];
    
    // remove licenses
    for(NSInteger i = 0; i < [licenseFiles count]; ++i)
    {
        NSString *fp =  [licenseFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR22");
        }
    }
    
    // remove remaining licenses
    for(NSInteger i = 0; i < [remlicFiles count]; ++i)
    {
        NSString *fp =  [remlicFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR21");
        }
    }

    // remove allapps files
    for(NSInteger i = 0; i < [allappsFiles count]; ++i)
    {
        NSString *fp =  [allappsFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR10");
        }
    }
    
    // remove alldevices files
    for(NSInteger i = 0; i < [alldevFiles count]; ++i)
    {
        NSString *fp =  [alldevFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR19");
        }
    }

    // remove BytaFont Backup
    for(NSInteger i = 0; i < [bytafontFiles count]; ++i)
    {
        NSString *fp =  [bytafontFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR18");
        }
    }

    // remove Apple PLISTs
    for(NSInteger i = 0; i < [appleFiles count]; ++i)
    {
        NSString *fp =  [appleFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR17");
        }
    }

    // remove Apple PLISTs
    for(NSInteger i = 0; i < [nfcdFiles count]; ++i)
    {
        NSString *fp =  [nfcdFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR16");
        }
    }

    // remove Bytafont PLISTs
    for(NSInteger i = 0; i < [bytaplistFiles count]; ++i)
    {
        NSString *fp =  [bytaplistFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR15");
        }
    }

    // remove Assistant+ PLISTs
    for(NSInteger i = 0; i < [siriplusFiles count]; ++i)
    {
        NSString *fp =  [siriplusFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR14");
        }
    }

    // remove customft PLISTs
    for(NSInteger i = 0; i < [customftFiles count]; ++i)
    {
        NSString *fp =  [customftFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR13");
        }
    }

    // remove wave PLISTs
    for(NSInteger i = 0; i < [waveFiles count]; ++i)
    {
        NSString *fp =  [waveFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR12");
        }
    }

    // remove Peekaboo PLISTs
    for(NSInteger i = 0; i < [peekabooFiles count]; ++i)
    {
        NSString *fp =  [peekabooFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR11");
        }
    }

    // remove Senddelay PLISTs
    for(NSInteger i = 0; i < [senddelayFiles count]; ++i)
    {
        NSString *fp =  [senddelayFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR0");
        }
    }

    // remove RevealMenu PLISTs
    for(NSInteger i = 0; i < [revealmenuFiles count]; ++i)
    {
        NSString *fp =  [revealmenuFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR9");
        }
    }

    // remove CarPlay PLISTs
    for(NSInteger i = 0; i < [carplayFiles count]; ++i)
    {
        NSString *fp =  [carplayFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR8");
        }
    }

    // remove Instabetter PLISTs
    for(NSInteger i = 0; i < [instabetterFiles count]; ++i)
    {
        NSString *fp =  [instabetterFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR7");
        }
    }
    
    // remove ForceGoodFit PLISTs
    for(NSInteger i = 0; i < [fgfFiles count]; ++i)
    {
        NSString *fp =  [fgfFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR6");
        }
    }
    
    // remove Curiosa PLISTs
    for(NSInteger i = 0; i < [curiosaFiles count]; ++i)
    {
        NSString *fp =  [curiosaFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR5");
        }
    }
    
    // remove Cydia PLISTs
    for(NSInteger i = 0; i < [cydiaFiles count]; ++i)
    {
        NSString *fp =  [cydiaFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR2");
        }
    }
    
    // remove Filza PLISTs
    for(NSInteger i = 0; i < [filzaFiles count]; ++i)
    {
        NSString *fp =  [filzaFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR1");
        }
    }
    
    // remove 3DAppLock PLISTs
    for(NSInteger i = 0; i < [forceapplockFiles count]; ++i)
    {
        NSString *fp =  [forceapplockFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR3");
        }
    }
    
    // remove ProgrammableSMS PLISTs
    for(NSInteger i = 0; i < [progsmsFiles count]; ++i)
    {
        NSString *fp =  [progsmsFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR4");
        }
    }
    
    // remove Crash PLISTs
    for(NSInteger i = 0; i < [crashFiles count]; ++i)
    {
        NSString *fp =  [crashFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR181");
        }
    }
    
    // remove Apple PLISTs
    for(NSInteger i = 0; i < [moreappleFiles count]; ++i)
    {
        NSString *fp =  [moreappleFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR1711");
        }
    }
    
    // remove Apple PLISTs
    for(NSInteger i = 0; i < [evenmoreappleFiles count]; ++i)
    {
        NSString *fp =  [evenmoreappleFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR161");
        }
    }
    
    // remove Apple PLISTs
    for(NSInteger i = 0; i < [exmoreappleFiles count]; ++i)
    {
        NSString *fp =  [exmoreappleFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR151");
        }
    }

    // remove Apple PLISTs
    for(NSInteger i = 0; i < [ridmoreappleFiles count]; ++i)
    {
        NSString *fp =  [ridmoreappleFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR141");
        }
    }

    // remove Apple PLISTs
    for(NSInteger i = 0; i < [NOMOREappleFiles count]; ++i)
    {
        NSString *fp =  [NOMOREappleFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR131");
        }
    }

    // remove Apple PLISTs
    for(NSInteger i = 0; i < [isitoverappleFiles count]; ++i)
    {
        NSString *fp =  [isitoverappleFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR121");
        }
    }

    // remove Activator PLISTs
    for(NSInteger i = 0; i < [libactFiles count]; ++i)
    {
        NSString *fp =  [libactFiles objectAtIndex: i];
        NSString *remPath = [path stringByAppendingPathComponent: fp];
        if ([manager removeItemAtPath: remPath error: nil]){
            NSLog(@"Delete Success");
        }
        else{
            NSLog(@"DELETE ERROR111");
        }
    }

    
        [pool drain];
        return 0;
        
    
}
@end